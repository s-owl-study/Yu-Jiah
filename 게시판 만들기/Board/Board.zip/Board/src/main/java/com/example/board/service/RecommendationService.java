package com.example.board.service;

public class RecommendationService {
}
