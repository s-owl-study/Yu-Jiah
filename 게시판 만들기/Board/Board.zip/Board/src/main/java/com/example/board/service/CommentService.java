package com.example.board.service;

import com.example.board.dto.CommentDto;

public class CommentService{

        //댓글 작성
        public void createComment(CommentDto commentDto){

        }

        //댓글 수정
        public void updateComment(Long commentNo){

        }

        //댓글 삭제
        public void deleteComment(Long commentNo){

        }
    }

}
